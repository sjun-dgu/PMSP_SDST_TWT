import json
import os, re, argparse, pandas as pd, openai
import time
from dataclasses import dataclass
import instructor
import requests
import xai_sdk
from google import genai
from module import *
import copy
import config
from pydantic import BaseModel
from google.genai import types
import toolbox
from typing import Optional
import priority_functions

WITH_CONTEXT = True
WITH_REASONING = False
GEMINI_MAX_TRY = 50
JOB_FILTER = True
JOB_FILTER_CNT = 50

#TODO: Contextual INPUT - The other machines info
#TODO: with and without reasoning
client = openai.OpenAI(api_key=config.OPENAI_API_KEY)

@dataclass
class Job_Info:
    id: int = -1; p: int = -1; s: int = -1; d: int = -1; w: int = -1; f: int = -1

class Job_Choice(BaseModel):
    job_id: int

class Job_Choice_Reason(BaseModel):
    job_id: int
    reasoning: str

class Job_Choice_Guided(BaseModel):
    keep_current : bool
    other_job_id: Optional[int]
    reason: Optional[str]

PROMPT = """
You must choose the best job from the following jobs on a machine among {m} {m_type}machines that can start the job at time {now}.

{n} jobs waiting in queue:

{jobs}

{context}

Select one job ID to be processed next to minimize future weighted total tardiness after processing all the jobs with {m} machines.
""".strip()

PROMPT_T = """
You must choose the best job from the following jobs on a machine among {m} {m_type}machines that can start the job at time {now}.

{n} jobs waiting in queue:

{jobs}

Sequence-dependent setup times are as follows:

{setup_times}

{context}

Select one job ID to be processed next to minimize future total tardiness after processing all the jobs with {m} machines.
""".strip()

PROMPT_SETUP = """
You must choose the best job from the following jobs on a machine among {m} {m_type}machines that can start the job at time {now}.

{n} jobs waiting in queue:

{jobs}

Sequence-dependent setup times are as follows:

{setup_times}

{context}

Select one job ID to be processed next to minimize future weighted total tardiness after processing all the jobs with {m} machines.
""".strip()

PROMPT_KEEP = """
You are selecting the next job for a single machine (one of {m} {m_type} machines) that can start at time {now}. Choose the job that minimizes future total tardiness after all remaining jobs on this machine are processed.

Queue (n = {n}): {jobs}

Sequence-dependent setup times: {setup_times}

Context: {context}

ATCS recommends: Job {atcs}

Decide whether to keep ATCS’s choice or recommend a different job ID. If you deviate, justify your recommendation briefly.
""".strip()

def build_prompt(prob: Instance, jobs: List[Job], mch: Machine, t_now: int) -> str:
    waiting = [Job_Info(id=job.ID, p=mch.get_ptime(job), s=mch.get_setup(job), d=job.due, w=job.weight, f=job.family) for job in jobs if job.complete == False]
    m_type = ''
    if prob.identical_mch:
        m_type = 'identical '
    else:
        m_type = 'unrelated '

    if prob.with_setup:
        if prob.family_setup:
            jobs_list = "\n".join(
                f"- Job {j.id}: Weight {j.w}, Processing Time {j.p}, Setup Time {j.s}, Due {j.d}, Family {j.f}"
                for j in waiting)
            setup_list = "\n".join(
                f"- Family {f1} to Family {f2}: {mch.family_setup_times[f1][f2]}"
                for f1 in range(len(mch.family_setup_times)) for f2 in range(len(mch.family_setup_times)))
        else:
            jobs_list = "\n".join(
                f"- Job {j.id}: Weight {j.w}, Processing Time {j.p}, Setup Time {j.s}, Due {j.d}"
                for j in waiting)
            setup_list = "\n".join(
                f"- Job {j1.id} to Job {j2.id}: {mch.setup[j1.id][j2.id]}"
                for j1 in waiting for j2 in waiting)
    else:
        jobs_list = "\n".join(
            f"- Job {j.id}: Weight {j.w}, Processing Time {j.p}, Due {j.d}"
            for j in waiting)
        if prob.objective == 'T':
            jobs_list = "\n".join(
                f"- Job {j.id}: Processing Time {j.p}, Due {j.d}"
                for j in waiting)

    context = ''
    if WITH_CONTEXT:
        context=f"Information about the other {len(prob.machine_list)-1} machines is as follow:\n"
        for other_mch in prob.machine_list:
            if other_mch.ID != mch.ID:
                context += f"- Machine {other_mch.ID} available at time {other_mch.available}\n"

    if prob.with_setup:
        result = PROMPT_SETUP.format(now=t_now, n=len(waiting), jobs=jobs_list, setup_times=setup_list, m=len(prob.machine_list), context=context, m_type=m_type)
    else:
        result = PROMPT.format(now=t_now, n=len(waiting), jobs=jobs_list, m=len(prob.machine_list), context=context, m_type=m_type)
        if prob.objective == 'T':
            result = PROMPT_T.format(now=t_now, n=len(waiting), jobs=jobs_list, m=len(prob.machine_list), context=context, m_type=m_type)
    return result

def build_prompt_keep(prob: Instance, jobs: List[Job], mch: Machine, t_now: int) -> str:
    waiting = [Job_Info(id=job.ID, p=mch.get_ptime(job), s=mch.get_setup(job), d=job.due, w=job.weight, f=job.family) for job in jobs if job.complete == False]
    waiting_jobs = [job for job in jobs if job.complete == False]
    for j in waiting_jobs:
        j.priority = priority_functions.atcs(prob, j, mch)
    best_atcs = min(waiting_jobs, key=lambda j: j.priority)
    m_type = ''
    if prob.identical_mch:
        m_type = 'identical '
    else:
        m_type = 'unrelated '

    if prob.with_setup:
        if prob.family_setup:
            jobs_list = "\n".join(
                f"- Job {j.id}: Weight {j.w}, Processing Time {j.p}, Setup Time {j.s}, Due {j.d}, Family {j.f}"
                for j in waiting)
            setup_list = "\n".join(
                f"- Family {f1} to Family {f2}: {mch.family_setup_times[f1][f2]}"
                for f1 in range(len(mch.family_setup_times)) for f2 in range(len(mch.family_setup_times)))
        else:
            jobs_list = "\n".join(
                f"- Job {j.id}: Weight {j.w}, Processing Time {j.p}, Setup Time {j.s}, Due {j.d}"
                for j in waiting)
            setup_list = "\n".join(
                f"- Job {j1.id} to Job {j2.id}: {mch.setup[j1.id][j2.id]}"
                for j1 in waiting for j2 in waiting)
    else:
        jobs_list = "\n".join(
            f"- Job {j.id}: Weight {j.w}, Processing Time {j.p}, Due {j.d}"
            for j in waiting)
        if prob.objective == 'T':
            jobs_list = "\n".join(
                f"- Job {j.id}: Processing Time {j.p}, Due {j.d}"
                for j in waiting)

    context = ''
    if WITH_CONTEXT:
        context=f"Information about the other {len(prob.machine_list)-1} machines is as follow:\n"
        for other_mch in prob.machine_list:
            if other_mch.ID != mch.ID:
                context += f"- Machine {other_mch.ID} available at time {other_mch.available}\n"

    result = PROMPT_KEEP.format(now=t_now, n=len(waiting), jobs=jobs_list, m=len(prob.machine_list), context=context, m_type=m_type, setup_times=setup_list, atcs=best_atcs.ID)

    return result, best_atcs

def scheduling_openai(_prob: Instance, with_ft: bool = False) -> Schedule:
    global WITH_CONTEXT, WITH_REASONING

    def llm_choose_one(jobs: List[Job], mch: Machine, t_now: int, exclude: List[Job]) -> int:
        test = build_prompt(prob, jobs, mch, t_now)
        if len(exclude) != 0:
            exclude_jobs = "except ".join(
                f"{j.ID}, " for j in exclude)
        else:
            exclude_jobs = ""
        if with_ft:
            model = config.OPENAI_FT_MODEL_ID
        else:
            model = config.OPENAI_MODEL
        if WITH_REASONING:
            reply = client.chat.completions.parse(
                model=model,
                messages=[
                    {"role": "system",
                     "content": "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs)},
                    {"role": "user",
                     "content": test}],
                response_format=Job_Choice_Reason,
                temperature=0.0,
            )
        else:
            reply = client.chat.completions.parse(
                model=model,
                messages=[
                    {"role": "system",
                     "content": "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs)},
                    {"role": "user",
                     "content": test}],
                response_format=Job_Choice,
                temperature=0.0,
            )

        result = reply.choices[0].message.parsed
        return result.job_id

    prob = copy.deepcopy(_prob)
    start_time = time.perf_counter()
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        # TODO: Implement LLM-based Dispatching Here
        # job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available)
        # chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
        exclude_jobs = []
        chosen_job = None
        while True:
            if wrong_job_cnt >= GEMINI_MAX_TRY:
                break
            job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available, exclude_jobs)
            if job_id >= len([job.ID for job in prob.job_list]):
                wrong_job_cnt += 1
            elif job_id not in [job.ID for job in wait_jobs]:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                exclude_jobs.append(chosen_job)
                wrong_job_cnt += 1
            else:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                break
        if chosen_job is None:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=-1)
            result.comp_time = elapsed_time
            result.status = "Hallucination Count: {}".format(wrong_job_cnt)
            break
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=obj)
    result.print_schedule()
    result.comp_time = elapsed_time
    result.status = wrong_job_cnt

    return result

def scheduling_claude(_prob: Instance, with_ft: bool = False) -> Schedule:
    global WITH_CONTEXT, WITH_REASONING
    os.environ["ANTHROPIC_API_KEY"] = config.CLAUDE_API_KEY
    client = instructor.from_provider(
        "anthropic/{0}".format(config.CLAUDE_MODEL),
        mode=instructor.Mode.ANTHROPIC_TOOLS
    )

    def llm_choose_one(jobs: List[Job], mch: Machine, t_now: int, exclude: List[Job]) -> int:
        test = build_prompt(prob, jobs, mch, t_now)
        if len(exclude) != 0:
            exclude_jobs = "except ".join(
                f"{j.ID}, " for j in exclude)
        else:
            exclude_jobs = ""
        if with_ft:
            model = config.OPENAI_FT_MODEL_ID
        else:
            model = config.CLAUDE_MODEL
        if WITH_REASONING:
            reply = client.chat.completions.create(
                model=model,
                system="You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs),
                messages=[
                    {"role": "user", "content": test}
                ],
                max_tokens=config.CLAUDE_MAX_TOKEN,
                response_model=Job_Choice_Reason,
            )
        else:
            reply = client.chat.completions.create(
                model=model,
                system="You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs),
                messages=[
                    {"role": "user", "content": test}
                ],
                max_tokens=config.CLAUDE_MAX_TOKEN,
                response_model=Job_Choice,
            )
        result = reply
        return result.job_id

    prob = copy.deepcopy(_prob)
    start_time = time.perf_counter()
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        exclude_jobs = []
        chosen_job = None
        while True:
            if wrong_job_cnt >= GEMINI_MAX_TRY:
                break
            job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available, exclude_jobs)
            if job_id >= len([job.ID for job in prob.job_list]):
                wrong_job_cnt += 1
            elif job_id not in [job.ID for job in wait_jobs]:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                exclude_jobs.append(chosen_job)
                wrong_job_cnt += 1
            else:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                break
        if chosen_job is None:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=-1)
            result.comp_time = elapsed_time
            result.status = "Hallucination Count: {}".format(wrong_job_cnt)
            break
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule('LLM with {0}'.format(config.CLAUDE_MODEL), prob, obj=obj)
    result.status = wrong_job_cnt
    result.print_schedule()
    result.comp_time = elapsed_time

    return result

def scheduling_gemini(_prob: Instance, with_ft: bool = False) -> Schedule:
    global WITH_CONTEXT, WITH_REASONING

    if not with_ft:
        client = genai.Client(api_key=config.GEMINI_API_KEY)
    else:
        credential_path = "C:\plaid.json"
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credential_path
        client = genai.Client(vertexai=True, project=config.GEMINI_PROJECT_ID, location=config.GEMINI_REGION)

    def llm_choose_one(jobs: List[Job], mch: Machine, t_now: int, exclude: List[Job]) -> int:
        test = build_prompt(prob, jobs, mch, t_now)
        if len(exclude) != 0:
            exclude_jobs = "except ".join(
                f"{j.ID}, " for j in exclude)
        else:
            exclude_jobs = ""
        if not with_ft:
            if WITH_REASONING:
                prompt = (
                        "System: You are a production scheduler. "
                        f"Choose the best job id except {exclude_jobs} within 1 seconds.\n"
                        "User: " + test
                )
                response = client.models.generate_content(
                    model=config.GEMINI_MODEL,
                    contents=prompt,
                    config={
                        "response_mime_type": "application/json",
                        "response_schema": list[Job_Choice_Reason],
                    },
                )
            else:
                prompt = (
                        "System: You are a production scheduler. "
                        f"Choose the best job id except {exclude_jobs} within 1 seconds.\n"
                        "User: " + test
                )
                response = client.models.generate_content(
                    model=config.GEMINI_MODEL,
                    contents=prompt,
                    config={
                        "response_mime_type": "application/json",
                        "response_schema": list[Job_Choice],
                    },
                )
            result = response.parsed[0]
            return result.job_id
        else:
            if WITH_REASONING:
                prompt = (
                        "System: You are a production scheduler. "
                        f"Choose the best job id except {exclude_jobs} within 1 seconds.\n"
                        "User: " + test
                )
                # response = client.models.generate_content(
                #     model=config.GEMINI_FT_MODEL_ID,
                #     contents=prompt,
                #     config=types.GenerateContentConfig(
                #         response_mime_type="application/json",
                #         response_schema=list[Job_Choice_Reason]
                #     ),
                # )
                response = client.models.generate_content(
                    model=config.GEMINI_FT_MODEL_ID,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        response_mime_type="text/plain",
                    ),
                )
                raw = response.candidates[0].content  # e.g. "19"
                job_id = int(raw.parts[0].text)
            else:
                prompt = (
                        "System: You are a production scheduler. "
                        f"Choose the best job id except {exclude_jobs} within 1 seconds.\n"
                        "User: " + test
                )
                # response = client.models.generate_content(
                #     model=config.GEMINI_FT_MODEL_ID,
                #     contents=prompt,
                #     config=types.GenerateContentConfig(
                #         response_mime_type="application/json",
                #         response_schema=list[Job_Choice]
                #     ),
                # )
                response = client.models.generate_content(
                    model=config.GEMINI_FT_MODEL_ID,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        response_mime_type="text/plain",
                    ),
                )
                raw = response.candidates[0].content  # e.g. "19"
                job_id = int(raw.parts[0].text)
            # result = response.candidates[0].content
            # data = json.loads(result.parts[0].text)  # 문자열을 파이썬 객체로 변환
            # job_id = data[0]['job_id']  # 리스트 첫 번째 요소의 'job_id' 값 추출
            return job_id

    prob = copy.deepcopy(_prob)
    start_time = time.perf_counter()
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        # TODO: Implement LLM-based Dispatching Here
        # job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available)
        # chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
        exclude_jobs = []
        chosen_job = None
        while True:
            if wrong_job_cnt >= GEMINI_MAX_TRY:
                break
            job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available, exclude_jobs)
            if job_id >= len([job.ID for job in prob.job_list]):
                wrong_job_cnt += 1
            elif job_id not in [job.ID for job in wait_jobs]:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                exclude_jobs.append(chosen_job)
                wrong_job_cnt += 1
            else:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                break
        if chosen_job is None:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=-1)
            result.comp_time = elapsed_time
            result.status = "Hallucination Count: {}".format(wrong_job_cnt)
            break
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule('LLM with {0}'.format(config.GEMINI_MODEL), prob, obj=obj)
    result.print_schedule()
    result.comp_time = elapsed_time
    result.status = wrong_job_cnt

    return result

def scheduling_perplexity(_prob: Instance) -> Schedule:
    global WITH_CONTEXT, WITH_REASONING

    def llm_choose_one(jobs: List[Job], mch: Machine, t_now: int, exclude: List[Job]) -> int:
        test = build_prompt(prob, jobs, mch, t_now)
        if len(exclude) != 0:
            exclude_jobs = "except ".join(
                f"{j.ID}, " for j in exclude)
        else:
            exclude_jobs = ""
        model = config.PERPLEXITY_MODEL
        if WITH_REASONING:
            url = "https://api.perplexity.ai/chat/completions"
            headers = {"Authorization": "Bearer {}".format(config.PERPLEXITY_API_KEY)}
            payload = {
                "model": config.PERPLEXITY_MODEL,
                "messages": [
                    {"role": "system",
                     "content": "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs)},
                    {"role": "user",
                     "content": test}],
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"schema": Job_Choice_Reason.model_json_schema()},
                },
            }
            response = requests.post(url, headers=headers, json=payload).json()
            result = Job_Choice_Reason.model_validate_json(response["choices"][0]["message"]["content"])
        else:
            url = "https://api.perplexity.ai/chat/completions"
            headers = {"Authorization": "Bearer {}".format(config.PERPLEXITY_API_KEY)}
            payload = {
                "model": config.PERPLEXITY_MODEL,
                "messages": [
                    {"role": "system",
                     "content": "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs)},
                    {"role": "user",
                     "content": test}],
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"schema": Job_Choice.model_json_schema()},
                },
            }
            response = requests.post(url, headers=headers, json=payload).json()
            result = Job_Choice.model_validate_json(response["choices"][0]["message"]["content"])
        return result.job_id

    prob = copy.deepcopy(_prob)
    start_time = time.perf_counter()
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        # TODO: Implement LLM-based Dispatching Here
        # job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available)
        # chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
        exclude_jobs = []
        chosen_job = None
        while True:
            if wrong_job_cnt >= GEMINI_MAX_TRY:
                break
            job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available, exclude_jobs)
            if job_id >= len([job.ID for job in prob.job_list]):
                wrong_job_cnt += 1
            elif job_id not in [job.ID for job in wait_jobs]:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                exclude_jobs.append(chosen_job)
                wrong_job_cnt += 1
            else:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                break
        if chosen_job is None:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=-1)
            result.comp_time = elapsed_time
            result.status = "Hallucination Count: {}".format(wrong_job_cnt)
            break
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule('LLM with {0}'.format(config.PERPLEXITY_MODEL), prob, obj=obj)
    result.print_schedule()
    result.comp_time = elapsed_time
    result.status = wrong_job_cnt

    return result

def scheduling_xai(_prob: Instance) -> Schedule:
    global WITH_CONTEXT, WITH_REASONING

    def llm_choose_one(jobs: List[Job], mch: Machine, t_now: int, exclude: List[Job]) -> int:
        test = build_prompt(prob, jobs, mch, t_now)
        if len(exclude) != 0:
            exclude_jobs = "except ".join(
                f"{j.ID}, " for j in exclude)
        else:
            exclude_jobs = ""
        model = config.PERPLEXITY_MODEL
        if WITH_REASONING:
            client = xai_sdk.Client(api_key=config.XAI_API_KEY)
            chat = client.chat.create(model=config.XAI_MODEL)  #
            chat.append(
                xai_sdk.chat.system(
                    "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs)))
            chat.append(
                xai_sdk.chat.user(test)
            )
            result = chat.parse(Job_Choice_Reason)
        else:
            client = xai_sdk.Client(api_key=config.XAI_API_KEY)
            chat = client.chat.create(model=config.XAI_MODEL)  #
            chat.append(
                xai_sdk.chat.system(
                    "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                        get_obj_name(prob.objective), exclude_jobs)))
            chat.append(
                xai_sdk.chat.user(test)
            )
            result = chat.parse(Job_Choice)
        return result[1].job_id

    prob = copy.deepcopy(_prob)
    start_time = time.perf_counter()
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        # TODO: Implement LLM-based Dispatching Here
        # job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available)
        # chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
        exclude_jobs = []
        chosen_job = None
        while True:
            if wrong_job_cnt >= GEMINI_MAX_TRY:
                break
            job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available, exclude_jobs)
            if job_id >= len([job.ID for job in prob.job_list]):
                wrong_job_cnt += 1
            elif job_id not in [job.ID for job in wait_jobs]:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                exclude_jobs.append(chosen_job)
                wrong_job_cnt += 1
            else:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                break
        if chosen_job is None:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=-1)
            result.comp_time = elapsed_time
            result.status = "Hallucination Count: {}".format(wrong_job_cnt)
            break
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule('LLM with {0}'.format(config.XAI_MODEL), prob, obj=obj)
    result.print_schedule()
    result.comp_time = elapsed_time
    result.status = wrong_job_cnt

    return result

def get_total_token(_prob: Instance) -> (int, int):
    total_input_token = 0
    total_comp_token = 0
    prob = copy.deepcopy(_prob)
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        total_input_token += toolbox.calculate_token(build_prompt(prob, wait_jobs, chosen_mch, chosen_mch.available))
        chosen_job = wait_jobs[0]
        total_comp_token += 14
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]

    return total_input_token, total_comp_token

def scheduling_openai5(_prob: Instance, with_ft: bool = False) -> Schedule:
    global WITH_CONTEXT, WITH_REASONING
    efforts = 'minimal'

    def llm_choose_one(jobs: List[Job], mch: Machine, t_now: int, exclude: List[Job]) -> int:
        test = build_prompt(prob, jobs, mch, t_now)
        if len(exclude) != 0:
            exclude_jobs = "except ".join(
                f"{j.ID}, " for j in exclude)
        else:
            exclude_jobs = ""
        if with_ft:
            model = config.OPENAI_FT_MODEL_ID
        else:
            model = config.OPENAI_MODEL
        if WITH_REASONING:
            reply = client.chat.completions.parse(
                model=model,
                messages=[
                    {"role": "system",
                     "content": "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs)},
                    {"role": "user",
                     "content": test}],
                reasoning_effort=efforts,
                response_format=Job_Choice_Reason,
            )
        else:
            reply = client.chat.completions.parse(
                model=model,
                messages=[
                    {"role": "system",
                     "content": "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
                         get_obj_name(prob.objective), exclude_jobs)},
                    {"role": "user",
                     "content": test}],
                reasoning_effort=efforts,
                response_format=Job_Choice,
            )

        result = reply.choices[0].message.parsed
        return result.job_id

    prob = copy.deepcopy(_prob)
    start_time = time.perf_counter()
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        # TODO: Implement LLM-based Dispatching Here
        # job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available)
        # chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
        exclude_jobs = []
        chosen_job = None
        while True:
            if wrong_job_cnt >= GEMINI_MAX_TRY:
                break
            job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available, exclude_jobs)
            if job_id >= len([job.ID for job in prob.job_list]):
                wrong_job_cnt += 1
            elif job_id not in [job.ID for job in wait_jobs]:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                exclude_jobs.append(chosen_job)
                wrong_job_cnt += 1
            else:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                break
        if chosen_job is None:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=-1)
            result.comp_time = elapsed_time
            result.status = "Hallucination Count: {}".format(wrong_job_cnt)
            break
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=obj)
    result.print_schedule()
    result.comp_time = elapsed_time
    result.status = wrong_job_cnt

    return result

def scheduling_openai_keep(_prob: Instance, with_ft: bool = False) -> Schedule:
    global WITH_CONTEXT, WITH_REASONING

    def llm_choose_one(jobs: List[Job], mch: Machine, t_now: int, exclude: List[Job]) -> int:
        test, atcs = build_prompt_keep(prob, jobs, mch, t_now)
        # if len(exclude) != 0:
        #     exclude_jobs = "except ".join(
        #         f"{j.ID}, " for j in exclude)
        # else:
        #     exclude_jobs = ""
        # if with_ft:
        #     model = config.OPENAI_FT_MODEL_ID
        # else:
        #     model = config.OPENAI_MODEL
        # reply = client.chat.completions.parse(
        #     model=model,
        #     messages=[
        #         {"role": "system",
        #          "content": "You are a production scheduler to minimize {0}. Find the best job's id {1} as quick as possible".format(
        #              get_obj_name(prob.objective), exclude_jobs)},
        #         {"role": "user",
        #          "content": test}],
        #     response_format=Job_Choice_Guided,
        #     temperature=0.0,
        # )
        #
        # result = reply.choices[0].message.parsed
        # if not result.keep_current:
        #     return result.other_job_id
        # else:
        #     return atcs.ID
        return atcs.ID

    prob = copy.deepcopy(_prob)
    start_time = time.perf_counter()
    wait_jobs = [job for job in prob.job_list if job.complete is False]
    if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    wrong_job_cnt = 0
    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        chosen_mch = machines[0]
        # TODO: Implement LLM-based Dispatching Here
        # job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available)
        # chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
        exclude_jobs = []
        chosen_job = None
        while True:
            if wrong_job_cnt >= GEMINI_MAX_TRY:
                break
            job_id = llm_choose_one(wait_jobs, chosen_mch, chosen_mch.available, exclude_jobs)
            if job_id >= len([job.ID for job in prob.job_list]):
                wrong_job_cnt += 1
            elif job_id not in [job.ID for job in wait_jobs]:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                exclude_jobs.append(chosen_job)
                wrong_job_cnt += 1
            else:
                chosen_job = [job for job in prob.job_list if job.ID == job_id][0]
                break
        if chosen_job is None:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=-1)
            result.comp_time = elapsed_time
            result.status = "Hallucination Count: {}".format(wrong_job_cnt)
            break
        chosen_mch.process(chosen_job)
        wait_jobs = [job for job in prob.job_list if job.complete is False]
        if JOB_FILTER: wait_jobs = sorted(wait_jobs, key=lambda x: x.due, reverse=False)[:JOB_FILTER_CNT]
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule('LLM with {0}'.format(config.OPENAI_MODEL), prob, obj=obj)
    result.print_schedule()
    result.comp_time = elapsed_time
    result.status = wrong_job_cnt

    return result