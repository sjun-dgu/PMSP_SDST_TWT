import time
from module import *
import copy
import math
import numpy as np
from random import uniform


def scheduling(_prob: Instance, rule: str) -> Schedule:
    '''
    This function is for finding a feasible solution for a given scheduling problem instance.
    :param prob: Problem Instance
    :param rule: Scheduling Rule (e.g. EDD, SPT, MST)
    :return: Schedule Result with Objective Function
    '''

    prob = copy.deepcopy(_prob)
    # prob = _prob
    start_time = time.perf_counter()
    def update_priority(job_list, mch_list):
        for j in job_list:
            if j.complete is False:
                if rule == 'EDD':
                    j.priority = j.due
                elif rule == 'SPT':  # This is an example of SPT
                    # j.priority = sum([m.ptime[j.ID] for m in mch_list])
                    j.priority = min(mch_list, key=lambda m: m.available).ptime[j.ID]
                elif rule == 'MST':  # This is an example of MST (Minimum Setup Time)
                    j.priority = min(mch_list, key=lambda m: m.available).get_setup(j)
                elif rule == 'COMP':  # This is an example of MST (Minimum Setup Time)
                    best_mch = min(mch_list, key=lambda m: m.available + m.get_setup(j) + m.get_ptime(j)) # 그전에는 이 앞에 ++m.get_ptime(j) 이러한 형태로 있었음
                    j.priority = best_mch.available + best_mch.get_setup(j) + best_mch.get_ptime(j)       # 그전에는 이 앞에 ++best_mch.get_ptime(j) 이러한 형태로 있었음
                elif rule == 'EXP_TARDY':
                    best_mch = min(mch_list, key=lambda m: m.available + m.get_setup(j) + m.get_ptime(j))
                    comp_times = best_mch.available + best_mch.get_setup(j) + best_mch.get_ptime(j)
                    j.priority = max(0, comp_times - j.due)
                elif rule == 'ATC':
                    k = 0.1
                    avg_ptimes = 0
                    waiting_jobs = 0
                    best_mch = min(mch_list, key=lambda m: m.available)
                    for job in (job_list_filter for job_list_filter in job_list if not job_list_filter.complete):
                        avg_ptimes += best_mch.get_ptime(job)
                        waiting_jobs += 1
                    if waiting_jobs == 0:
                        j.priority = -10000
                    else:
                        avg_ptimes = avg_ptimes / waiting_jobs
                        ptime = best_mch.get_ptime(j)
                        setup = best_mch.get_setup(j)
                        slack = j.due - best_mch.available - (ptime + setup)
                        atc = math.exp(-(max(0, slack) / (k * avg_ptimes))) / ptime
                        j.priority = -atc
                elif rule == 'COVERT':
                    k = 0.1
                    best_mch = min(mch_list, key=lambda m: m.available)
                    ptime = best_mch.get_ptime(j)
                    best_mch = min(mch_list, key=lambda m: m.available)
                    slack = j.due - best_mch.available - (ptime + best_mch.get_setup(j))
                    covert = max(0, 1 - (max(0, slack) / (k * ptime)))
                    j.priority = -(covert / ptime)
                elif rule == 'CR':
                    best_mch = min(mch_list, key=lambda m: m.available)
                    j.priority = (j.due - best_mch.available) / (best_mch.get_ptime(j) + best_mch.get_setup(j))
                elif rule == 'RT':
                    best_mch = min(mch_list, key=lambda m: m.available)
                    j.priority = j.due - (best_mch.get_ptime(j) + best_mch.get_setup(j))
                elif rule == 'MDD':
                    best_mch = min(mch_list, key=lambda m: m.available)
                    slack = j.due - best_mch.available - (best_mch.get_ptime(j) + best_mch.get_setup(j))
                    if slack > 0:
                        j.priority = j.due
                    else:
                        j.priority = best_mch.available + best_mch.get_ptime(j) + best_mch.get_setup(j)
                elif rule == 'SLACK':
                    best_mch = min(mch_list, key=lambda m: m.available)
                    j.priority = j.due - best_mch.available - (best_mch.get_ptime(j) + best_mch.get_setup(j))
                elif rule == 'ATCS':
                    best_mch = min(mch_list, key=lambda m: m.available)
                    k1 = 2.0
                    k2 = 0.5
                    avg_ptimes = 0
                    avg_stimes = 0
                    waiting_jobs = 0
                    ptime = best_mch.get_ptime(j)
                    setup = best_mch.get_setup(j)
                    for job in (job_list_filter for job_list_filter in job_list if not job_list_filter.complete):
                        avg_ptimes += best_mch.get_ptime(job)
                        avg_stimes += best_mch.get_setup(job)
                        waiting_jobs += 1
                    if waiting_jobs == 0:
                        j.priority = -10000
                    else:
                        avg_ptimes = avg_ptimes / waiting_jobs
                        avg_stimes = avg_stimes / waiting_jobs
                        if avg_stimes == 0:
                            avg_stimes = 1e-6
                        atcs = (j.weight / ptime) * np.exp(-max(j.due - ptime - best_mch.available, 0) / (k1 * avg_ptimes)) * np.exp(-setup / (k2 * avg_stimes))
                        j.priority = -atcs
                else: # If there is no rule, randomly select
                    j.priority = uniform(0.0, 1.0)
        return sorted((job for job in job_list if job.complete is False), key=lambda j: j.priority)

    wait_jobs = update_priority(prob.job_list, prob.machine_list)

    while len(wait_jobs) != 0:
        machines = sorted((mch for mch in prob.machine_list), key=lambda m: m.available)
        machines[0].process(wait_jobs[0])
        wait_jobs = update_priority(prob.job_list, prob.machine_list)

    end_time = time.perf_counter()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    obj = get_obj(prob)
    result = Schedule(rule, prob, obj=obj)
    result.comp_time = elapsed_time
    # result.print_schedule()

    return result
