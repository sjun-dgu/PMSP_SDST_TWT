import module
from module import *
from docplex.cp.model import *
import docplex.cp.utils_visu as visu
import matplotlib.pyplot as plt
from pylab import rcParams
from ortools.sat.python import cp_model
import numpy as np
import copy

def cp_scheduling(_prob: Instance, time_limit=300, init_sol: Schedule = None):
    prob = copy.deepcopy(_prob)
    nbrOfJobs = prob.numJob
    jobs = [*range(0, nbrOfJobs)]
    nbrOfMachines = prob.numMch
    machines = [*range(0, nbrOfMachines)]
    processingTimes = prob.ptime
    setup_matrix = prob.setup

    mdl = CpoModel(name='cp_model')

    prob.job_list = sorted((job for job in prob.job_list), key=lambda j: j.ID)
    prob.machine_list = sorted((mch for mch in prob.machine_list), key=lambda m: m.ID)

    processing_itv_vars = [[mdl.interval_var(start=(prob.machine_list[m].available, INTERVAL_MAX), optional=True,
                                             size=processingTimes[m][j], name="interval_job{}_machine{}".format(j, m))
                            for m in machines] for j in jobs]

    for j in jobs:
        mdl.add(mdl.sum([mdl.presence_of(processing_itv_vars[j][m]) for m in machines]) == 1)

    sequence_vars = [mdl.sequence_var([processing_itv_vars[j][m] for j in jobs], types=[j for j in jobs],
                                      name="sequences_machine{}".format(m)) for m in machines]

    if prob.with_setup:
        for m in machines:
            mdl.add(mdl.no_overlap(sequence_vars[m], setup_matrix[m], True))
    else:
        for m in machines:
            mdl.add(mdl.no_overlap(sequence_vars[m]))

    if prob.objective == 'T':
        objective = mdl.sum(
            [max(mdl.end_of(processing_itv_vars[j][m]) - prob.job_list[j].due, 0) for j in jobs for m in machines])
    elif prob.objective == 'wT':
        objective = mdl.sum(
            [prob.job_list[j].weight * max(mdl.end_of(processing_itv_vars[j][m]) - prob.job_list[j].due, 0) for j in
             jobs for m in machines])
    elif prob.objective == 'C':
        objective = mdl.sum([mdl.end_of(processing_itv_vars[j][m]) for j in jobs for m in machines])
    else:
        objective = max([mdl.end_of(processing_itv_vars[j][m]) for j in jobs for m in machines])
    mdl.add(mdl.minimize(objective))

    if init_sol is not None:
        stp = mdl.create_empty_solution()  # add_interval_var_solution(var, presence=None, start=None, end=None, size=None, length=None)
        for bar in init_sol.bars:
            stp.add_interval_var_solution(processing_itv_vars[bar.job.ID][bar.machine], presence=True, start=bar.start, end= bar.end)
        mdl.set_starting_point(stp)

    msol = mdl.solve(TimeLimit=time_limit)  # log_output=True
    print("Solution: ")
    msol.print_solution()

    MA = {i: [] for i in machines}
    for i in jobs:
        for k in machines:
            if msol.get_var_solution(processing_itv_vars[i][k]).end != None:
                print('Job {0} on Machine {1} completed at {2}'.format(i, k, msol.get_var_solution(
                    processing_itv_vars[i][k]).end))
                job_i = prob.findJob(i)
                job_i.end = msol.get_var_solution(processing_itv_vars[i][k]).end
                MA[k].append(job_i)
    for k in machines:
        MA[k] = sorted((job for job in MA[k]), key=lambda m: m.end)
        machine = prob.findMch(k)
        for job in MA[k]:
            machine.process(job)

    obj = get_obj(prob)
    result = Schedule('CP_CPLEX', prob, obj=obj)
    result.print_schedule()
    result.comp_time = msol.process_infos['TotalSolveTime']
    result.status = msol.solve_status
    if msol.solution.objective_values[0] != obj:
        result.status = 'Different Objective Values: CP {0} - Actual {1}'.format(msol.solution.objective_values[0], obj)
    return result