# heuristic/SA.py
# Simulated Annealing for Unrelated Parallel Machines with SDST
# (김 등, 2002 방식: LS 없음, 여러 이웃 연산 중 최선 후보 Y 선택 → 메트로폴리스 수용)
# Objective: Total Weighted Tardiness (wT) via module.get_obj
# input : module.Instance
# output: module.Schedule

from __future__ import annotations
import math, random, time
from dataclasses import dataclass
from typing import List, Tuple, Optional

from module import Instance, Schedule, get_obj

# ───────────────────────────────────────────────────────────────────────────────
# Data containers
# ───────────────────────────────────────────────────────────────────────────────

@dataclass
class Chromosome:
    seqs: List[List[int]]               # 길이 m, 각 원소는 job id list
    twt: Optional[int] = None           # total weighted tardiness
    machine_twt: Optional[List[int]] = None  # 머신별 TWT

    def copy(self) -> "Chromosome":
        return Chromosome([list(s) for s in self.seqs],
                          self.twt,
                          None if self.machine_twt is None else list(self.machine_twt))

# ───────────────────────────────────────────────────────────────────────────────
# Instance reset / cached arrays
# ───────────────────────────────────────────────────────────────────────────────

def reset_instance(inst: Instance) -> None:
    """Machine.process 전에 머신 상태 초기화 (오염 제거)"""
    for m in inst.machine_list:
        m.available = 0
        m.assigned = []
        m.schedules = []

def build_dw(inst: Instance) -> Tuple[List[int], List[int]]:
    """job_list에서 due/weight 배열 구성 (1회)"""
    n = inst.numJob
    d = [0]*n
    w = [0]*n
    for job in inst.job_list:
        d[job.ID] = job.due
        w[job.ID] = job.weight
    return d, w

# ───────────────────────────────────────────────────────────────────────────────
# Evaluation helpers
# ───────────────────────────────────────────────────────────────────────────────

def twt_of_machine(seq: List[int], mi: int, inst: Instance, d: List[int], w: List[int]) -> Tuple[int, List[int]]:
    """머신 mi 시퀀스의 (TWT, 완료시간 배열 C)"""
    if not seq:
        return 0, []
    p = inst.ptime
    s = inst.setup
    C, t = [], 0
    for k, j in enumerate(seq):
        setup = 0 if k == 0 else s[mi][seq[k-1]][j]
        t += setup + p[mi][j]
        C.append(t)
    twt = 0
    for k, j in enumerate(seq):
        tard = C[k] - d[j]
        if tard > 0:
            twt += w[j]*tard
    return twt, C

def evaluate_full(ch: Chromosome, inst: Instance, d: List[int], w: List[int]) -> Tuple[int, List[int]]:
    tot = 0
    mt = [0]*inst.numMch
    for mi in range(inst.numMch):
        val, _ = twt_of_machine(ch.seqs[mi], mi, inst, d, w)
        mt[mi] = val
        tot += val
    ch.twt = tot
    ch.machine_twt = mt
    return tot, mt

# ───────────────────────────────────────────────────────────────────────────────
# Position sampling: due 근처 ±window + 양끝
# ───────────────────────────────────────────────────────────────────────────────

def candidate_positions_by_due(seq: List[int], C: List[int], d: List[int], job: int, window: int = 10) -> List[int]:
    L = len(seq)
    if L == 0:
        return [0]
    tgt = d[job]
    best_k, best_gap = 0, abs(C[0]-tgt)
    for k in range(1, L):
        gap = abs(C[k]-tgt)
        if gap < best_gap:
            best_k, best_gap = k, gap
    left, right = max(0, best_k-window), min(L, best_k+window)
    cand = list(range(left, right+1))
    if 0 not in cand: cand.insert(0, 0)
    if L not in cand: cand.append(L)
    return sorted(set(cand))

# ───────────────────────────────────────────────────────────────────────────────
# Initial solution (EDD-ish greedy insert)
# ───────────────────────────────────────────────────────────────────────────────

def initial_solution(inst: Instance, d: List[int], w: List[int], rng: random.Random) -> Chromosome:
    jobs = list(range(inst.numJob))
    # EDD-like: due 오름차순 섞기(동due 랜덤)
    jobs.sort(key=lambda j: (d[j], rng.random()))
    ch = Chromosome([[] for _ in range(inst.numMch)])
    evaluate_full(ch, inst, d, w)
    for j in jobs:
        base_total = ch.twt or 0
        best = None
        best_delta = math.inf
        for mi in range(inst.numMch):
            seq = ch.seqs[mi]
            old, C = twt_of_machine(seq, mi, inst, d, w)
            poss = [0] if len(seq)==0 else candidate_positions_by_due(seq, C, d, j, window=8)
            for pos in poss:
                cand = seq[:pos] + [j] + seq[pos:]
                new, _ = twt_of_machine(cand, mi, inst, d, w)
                delta = (base_total - old) + new - base_total
                if delta < best_delta:
                    best_delta = delta
                    best = (mi, pos, new)
        mi, pos, new = best
        ch.seqs[mi].insert(pos, j)
        ch.twt = ch.twt - ch.machine_twt[mi] + new
        ch.machine_twt[mi] = new
    return ch

# ───────────────────────────────────────────────────────────────────────────────
# Neighborhoods (논문 맵핑; 전수조사 방지 위해 샘플/우선순위/윈도우 적용)
#   - NB1: intra-machine relocate (Item insert에 해당)
#   - NB2: inter-machine insertion (Lot insert에 해당)
#   - NB3: inter-machine swap (Item/Lot interchange)
#   * merge/split은 모듈이 분할 작업을 지원하지 않아 제외
# ───────────────────────────────────────────────────────────────────────────────

def nb_intra_relocate_best(ch: Chromosome, inst: Instance, d: List[int], w: List[int],
                           pos_window: int = 10, max_jobs_considered: int = 20) -> Tuple[Optional[Chromosome], int]:
    """같은 머신 내에서 작업 하나를 다른 위치로 이동 — 최선 후보 반환 (없으면 None)"""
    best_neigh, best_delta = None, math.inf
    for mi in sorted(range(inst.numMch), key=lambda i: ch.machine_twt[i], reverse=True):
        seq = ch.seqs[mi]
        L = len(seq)
        if L <= 1:
            continue
        base_total = ch.twt
        old, C = twt_of_machine(seq, mi, inst, d, w)
        idxs = list(range(L))
        idxs.sort(key=lambda k: ((C[k]-d[seq[k]])>0, w[seq[k]]), reverse=True)
        idxs = idxs[:min(L, max_jobs_considered)]
        for i in idxs:
            j = seq[i]
            poss = candidate_positions_by_due(seq, C, d, j, window=pos_window)
            if 0 not in poss: poss.insert(0, 0)
            if L not in poss: poss.append(L)
            for pos in poss:
                if pos == i or pos == i+1:
                    continue
                seq_wo = seq[:i] + seq[i+1:]
                pos_adj = pos if pos <= i else pos-1
                cand = seq_wo[:pos_adj] + [j] + seq_wo[pos_adj:]
                new, _ = twt_of_machine(cand, mi, inst, d, w)
                delta = (base_total - old) + new - base_total
                if delta < best_delta:
                    neigh = ch.copy()
                    neigh.seqs[mi] = cand
                    neigh.twt = ch.twt - ch.machine_twt[mi] + new
                    neigh.machine_twt[mi] = new
                    best_neigh, best_delta = neigh, delta
    return best_neigh, (0 if best_neigh is None else best_delta)

def nb_inter_insertion_best(ch: Chromosome, inst: Instance, d: List[int], w: List[int],
                            pos_window: int = 10, max_jobs_considered: int = 20) -> Tuple[Optional[Chromosome], int]:
    """한 머신에서 작업을 빼서 다른 머신에 삽입 — 최선 후보"""
    best_neigh, best_delta = None, math.inf
    m = inst.numMch
    order = sorted(range(m), key=lambda i: ch.machine_twt[i], reverse=True)
    for mi in order:
        seq_i = ch.seqs[mi]
        if not seq_i:
            continue
        old_i, C_i = twt_of_machine(seq_i, mi, inst, d, w)
        base_total = ch.twt
        idxs = list(range(len(seq_i)))
        idxs.sort(key=lambda k: ((C_i[k]-d[seq_i[k]])>0, w[seq_i[k]]), reverse=True)
        idxs = idxs[:min(len(seq_i), max_jobs_considered)]
        for idx_i in idxs:
            j = seq_i[idx_i]
            seq_i_wo = seq_i[:idx_i] + seq_i[idx_i+1:]
            new_i, _ = twt_of_machine(seq_i_wo, mi, inst, d, w)
            base_wo_i = (base_total - old_i) + new_i
            for mj in range(m):
                if mj == mi:
                    continue
                seq_j = ch.seqs[mj]
                old_j, C_j = twt_of_machine(seq_j, mj, inst, d, w)
                poss = [0] if len(seq_j)==0 else candidate_positions_by_due(seq_j, C_j, d, j, window=pos_window)
                if 0 not in poss: poss.insert(0, 0)
                if len(seq_j) not in poss: poss.append(len(seq_j))
                for pos in poss:
                    cand_j = seq_j[:pos] + [j] + seq_j[pos:]
                    new_j, _ = twt_of_machine(cand_j, mj, inst, d, w)
                    delta = base_wo_i - old_j + new_j - base_total
                    if delta < best_delta:
                        neigh = ch.copy()
                        del neigh.seqs[mi][idx_i]
                        neigh.seqs[mj] = cand_j
                        neigh.twt = ch.twt - ch.machine_twt[mi] - ch.machine_twt[mj] + new_i + new_j
                        neigh.machine_twt[mi] = new_i
                        neigh.machine_twt[mj] = new_j
                        best_neigh, best_delta = neigh, delta
    return best_neigh, (0 if best_neigh is None else best_delta)

def nb_inter_swap_best(ch: Chromosome, inst: Instance, d: List[int], w: List[int],
                       pos_window: int = 8, max_pairs_per_machine: int = 12) -> Tuple[Optional[Chromosome], int]:
    """두 머신 사이 작업 교환(각자 최적 삽입) — 최선 후보"""
    best_neigh, best_delta = None, math.inf
    m = inst.numMch
    order = sorted(range(m), key=lambda i: ch.machine_twt[i], reverse=True)
    for mi in order:
        seq_i = ch.seqs[mi]
        if not seq_i:
            continue
        old_i, C_i = twt_of_machine(seq_i, mi, inst, d, w)
        idxs_i = list(range(len(seq_i)))
        idxs_i.sort(key=lambda k: ((C_i[k]-d[seq_i[k]])>0, w[seq_i[k]]), reverse=True)
        idxs_i = idxs_i[:min(len(seq_i), max_pairs_per_machine)]
        for idx_i in idxs_i:
            x = seq_i[idx_i]
            seq_i_wo = seq_i[:idx_i] + seq_i[idx_i+1:]
            for mj in order:
                if mj == mi:
                    continue
                seq_j = ch.seqs[mj]
                if not seq_j:
                    continue
                old_j, C_j = twt_of_machine(seq_j, mj, inst, d, w)
                idxs_j = list(range(len(seq_j)))
                idxs_j.sort(key=lambda k: ((C_j[k]-d[seq_j[k]])>0, w[seq_j[k]]), reverse=True)
                idxs_j = idxs_j[:min(len(seq_j), max_pairs_per_machine)]
                for idx_j in idxs_j:
                    y = seq_j[idx_j]
                    seq_j_wo = seq_j[:idx_j] + seq_j[idx_j+1:]

                    # y를 i에, x를 j에 삽입(각자 best pos)
                    poss_i = [0] if len(seq_i_wo)==0 else candidate_positions_by_due(seq_i, C_i, d, y, window=pos_window)
                    if 0 not in poss_i: poss_i.insert(0,0)
                    if len(seq_i_wo) not in poss_i: poss_i.append(len(seq_i_wo))
                    best_i_val, best_i_pos = math.inf, 0
                    for pos_i in poss_i:
                        cand_i = seq_i_wo[:pos_i] + [y] + seq_i_wo[pos_i:]
                        val_i, _ = twt_of_machine(cand_i, mi, inst, d, w)
                        if val_i < best_i_val:
                            best_i_val, best_i_pos = val_i, pos_i

                    poss_j = [0] if len(seq_j_wo)==0 else candidate_positions_by_due(seq_j, C_j, d, x, window=pos_window)
                    if 0 not in poss_j: poss_j.insert(0,0)
                    if len(seq_j_wo) not in poss_j: poss_j.append(len(seq_j_wo))
                    best_j_val, best_j_pos = math.inf, 0
                    for pos_j in poss_j:
                        cand_j = seq_j_wo[:pos_j] + [x] + seq_j_wo[pos_j:]
                        val_j, _ = twt_of_machine(cand_j, mj, inst, d, w)
                        if val_j < best_j_val:
                            best_j_val, best_j_pos = val_j, pos_j

                    delta = (ch.twt - old_i - old_j + best_i_val + best_j_val) - ch.twt
                    if delta < best_delta:
                        neigh = ch.copy()
                        # 적용
                        del neigh.seqs[mi][idx_i]
                        del neigh.seqs[mj][idx_j if (mj!=mi) else (idx_j - (1 if idx_j>idx_i else 0))]
                        neigh.seqs[mi].insert(best_i_pos, y)
                        neigh.seqs[mj].insert(best_j_pos, x)
                        neigh.machine_twt[mi] = best_i_val
                        neigh.machine_twt[mj] = best_j_val
                        neigh.twt = ch.twt - old_i - old_j + best_i_val + best_j_val
                        best_neigh, best_delta = neigh, delta
    return best_neigh, (0 if best_neigh is None else best_delta)

def best_neighbor_among_ops(ch: Chromosome, inst: Instance, d: List[int], w: List[int]) -> Tuple[Chromosome, int]:
    """
    논문 흐름: 여러 연산 중 최선 후보 Y 선택 (전수조사X, 샘플 제한)
    반환: (neighbor, delta=neighbor.twt - ch.twt)
    """
    best_neigh, best_delta = None, math.inf

    n1, d1 = nb_intra_relocate_best(ch, inst, d, w, pos_window=10, max_jobs_considered=20)
    if n1 is not None and d1 < best_delta:
        best_neigh, best_delta = n1, d1

    n2, d2 = nb_inter_insertion_best(ch, inst, d, w, pos_window=10, max_jobs_considered=20)
    if n2 is not None and d2 < best_delta:
        best_neigh, best_delta = n2, d2

    n3, d3 = nb_inter_swap_best(ch, inst, d, w, pos_window=8, max_pairs_per_machine=12)
    if n3 is not None and d3 < best_delta:
        best_neigh, best_delta = n3, d3

    # 이웃을 하나도 못 만들면 자기 자신 반환
    if best_neigh is None:
        return ch.copy(), 0
    return best_neigh, best_delta

# ───────────────────────────────────────────────────────────────────────────────
# SA temperature helpers
# ───────────────────────────────────────────────────────────────────────────────

def estimate_initial_temperature(ch: Chromosome, inst: Instance, d: List[int], w: List[int],
                                 rng: random.Random, target_accept: float = 0.6,
                                 samples: int = 200) -> float:
    """양의 델타 평균으로 T0 추정: T0 = -avg_pos_delta / ln(target_accept)"""
    deltas = []
    for _ in range(samples):
        neigh, delta = best_neighbor_among_ops(ch, inst, d, w)
        if delta > 0:
            deltas.append(delta)
    if not deltas:
        return 1.0
    avg_pos = sum(deltas)/len(deltas)
    return max(1e-6, -avg_pos / math.log(target_accept))

# ───────────────────────────────────────────────────────────────────────────────
# SA main (논문: 매 스텝 최선 후보 Y 선택 → 메트로폴리스 규칙)
# ───────────────────────────────────────────────────────────────────────────────

def sa_schedulling(
    prob: Instance,
    time_limit_sec: float = 600.0,
    seed: Optional[int] = None,
    alpha: float = 0.95,                # geometric cooling
    epoch_factor: float = 1.0,          # epoch length = n * epoch_factor
    patience_epochs: int = 50,          # 개선 없는 에폭 허용
    instance_name: Optional[str] = None,
    max_epochs: int = 50_000,
    log_every_sec: float = 10.0,        # 10초마다 로그
) -> Schedule:
    """
    입력: module.Instance
    출력: module.Schedule (get_obj로 wT 계산)
    """
    rng = random.Random(seed)

    # 인스턴스 1회 deepcopy, d/w 캐시
    inst = prob.deepcopy()
    d, w = build_dw(inst)

    # 초기해
    cur = initial_solution(inst, d, w, rng)
    best = cur.copy()

    # T0 추정
    T = estimate_initial_temperature(cur, inst, d, w, rng, target_accept=0.6, samples=200)
    n = inst.numJob
    epoch_len = max(1, int(n * epoch_factor))

    # 로그 마일스톤 (에폭 10% 지점)
    if max_epochs and max_epochs > 0:
        epoch_marks = {max(1, math.ceil(max_epochs * k / 10)) for k in range(1, 11)}
    else:
        epoch_marks = set()
    t0 = time.time()
    next_time_log = t0 + log_every_sec
    name = instance_name or getattr(prob, "name", "unknown")
    print(f"[SA][{name}] start | time_limit={time_limit_sec}s | max_epochs={max_epochs} | T0={T:.3f} | epoch_len={epoch_len}")

    # SA 루프
    epoch = 0
    no_improve = 0
    while (time.time()-t0) < time_limit_sec and epoch < max_epochs and T > 1e-6:
        epoch += 1
        accepted = 0
        for _ in range(epoch_len):
            neigh, delta = best_neighbor_among_ops(cur, inst, d, w)  # 논문: 여러 연산 중 최선 후보 Y
            if delta <= 0:
                cur = neigh
                accepted += 1
                if cur.twt < best.twt:
                    best = cur.copy()
                    no_improve = 0
            else:
                # SA acceptance (메트로폴리스)
                if rng.random() < math.exp(-delta / T):
                    cur = neigh
                    accepted += 1
            # 시간 제한 빠른 체크
            if (time.time()-t0) >= time_limit_sec:
                break

        if cur.twt >= best.twt:
            no_improve += 1

        # 냉각
        T = T * alpha

        # 로그(10% 에폭 혹은 10초마다)
        now = time.time()
        if (epoch in epoch_marks) or (now >= next_time_log):
            pct = (100.0 * epoch / max_epochs) if max_epochs else 0.0
            print(f"[SA][{name}] epoch {epoch}/{max_epochs} ({pct:.1f}%) | T={T:.3f} | best_wT={best.twt} | accepted={accepted} | elapsed={now-t0:.1f}s")
            next_time_log = now + log_every_sec

        # 조기 종료: 개선 없을 때
        if no_improve >= patience_epochs:
            break

    print(f"[SA][{name}] done  | epoch={epoch}/{max_epochs} | best_wT={best.twt} | total_elapsed={(time.time()-t0):.1f}s")

    # ── 디코딩: Instance에 스케줄 반영 ────────────────────────────────────────
    reset_instance(inst)
    for mi, seq in enumerate(best.seqs):
        mch = inst.findMch(mi)
        for j in seq:
            job = inst.findJob(j)
            mch.process(job)

    obj = get_obj(inst)  # 기본 wT
    sched = Schedule('SA_TWT', inst, obj)
    sched.status = 'OK'
    sched.comp_time = f"{time.time()-t0:.3f}s"
    return sched
