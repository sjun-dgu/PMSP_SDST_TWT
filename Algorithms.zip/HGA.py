# heuristic/HGA_gpt.py
# Hybrid Genetic Algorithm (Local Search Enhanced One-Point Crossover)
# Objective: Total Weighted Tardiness (wT)
# input : module.Instance
# output: module.Schedule

from __future__ import annotations
import random, time, math
from dataclasses import dataclass
from typing import List, Tuple, Optional

from module import Instance, Schedule, get_obj  # get_obj는 wT 계산 지원

# ───────────────────────────────────────────────────────────────────────────────
# 염색체
# ───────────────────────────────────────────────────────────────────────────────

@dataclass
class Chromosome:
    seqs: List[List[int]]        # 길이 m, 각 원소는 job id list
    twt: Optional[int] = None    # total weighted tardiness
    machine_twt: Optional[List[int]] = None  # 머신별 TWT(우선순위용)

    def copy(self) -> "Chromosome":
        return Chromosome([list(x) for x in self.seqs],
                           self.twt,
                           None if self.machine_twt is None else list(self.machine_twt))

# ───────────────────────────────────────────────────────────────────────────────
# 유틸: Instance 초기화(재사용을 위해 상태 리셋)
# ───────────────────────────────────────────────────────────────────────────────

def reset_instance(inst: Instance) -> None:
    """Machine.process로 스케줄링하기 전, 머신 상태를 초기화(오염 제거)"""
    for m in inst.machine_list:
        m.available = 0
        m.assigned = []
        m.schedules = []

# ───────────────────────────────────────────────────────────────────────────────
# 평가 함수 (머신 단위 / 전체) — Instance를 직접 참조 (ptime/setup/job_list)
# ───────────────────────────────────────────────────────────────────────────────

def build_dw(inst: Instance) -> Tuple[List[int], List[int]]:
    """job_list에서 due/weight를 인덱스 접근 가능하게 배열로 빌드 (1회)"""
    n = inst.numJob
    d = [0]*n
    w = [0]*n
    for job in inst.job_list:
        d[job.ID] = job.due
        w[job.ID] = job.weight
    return d, w

def twt_of_machine(seq: List[int], m_idx: int, inst: Instance, d: List[int], w: List[int]) -> Tuple[int, List[int]]:
    """머신 m_idx의 시퀀스 seq에 대한 TWT와 완료시간 리스트 반환"""
    if not seq:
        return 0, []
    p = inst.ptime
    s = inst.setup
    C = []
    t = 0
    for k, j in enumerate(seq):
        if k == 0:
            setup = 0
        else:
            prev = seq[k-1]
            setup = s[m_idx][prev][j]
        t += setup + p[m_idx][j]
        C.append(t)
    twt = 0
    for k, j in enumerate(seq):
        tard = C[k] - d[j]
        if tard > 0:
            twt += w[j]*tard
    return twt, C

def evaluate_full(ch: Chromosome, inst: Instance, d: List[int], w: List[int]) -> Tuple[int, List[int]]:
    """염색체 전체 TWT와 머신별 기여도 계산 및 내부 캐시 업데이트"""
    total = 0
    machine_twt = [0]*inst.numMch
    for mi in range(inst.numMch):
        twt_m, _ = twt_of_machine(ch.seqs[mi], mi, inst, d, w)
        machine_twt[mi] = twt_m
        total += twt_m
    ch.twt = total
    ch.machine_twt = machine_twt
    return total, machine_twt

# ───────────────────────────────────────────────────────────────────────────────
# 포지션 후보(샘플링): EDD(납기) 근처 ±윈도우 + 양끝
# ───────────────────────────────────────────────────────────────────────────────

def candidate_positions_by_due(
    seq: List[int], C: List[int], d: List[int], job: int, window: int = 10
) -> List[int]:
    """해당 머신에서 job을 삽입할 유망 포지션 샘플"""
    L = len(seq)
    if L == 0:
        return [0]
    due = d[job]
    # due와 가장 가까운 완료시간 인덱스
    best_k = 0
    best_gap = abs(C[0] - due)
    for k in range(1, L):
        gap = abs(C[k] - due)
        if gap < best_gap:
            best_gap = gap
            best_k = k
    left = max(0, best_k - window)
    right = min(L, best_k + window)
    cand = list(range(left, right+1))
    # 항상 맨앞/맨뒤 포함
    if 0 not in cand: cand.insert(0, 0)
    if L not in cand: cand.append(L)
    return sorted(set(cand))

# ───────────────────────────────────────────────────────────────────────────────
# 초기해: 랜덤 순열 → 각 작업을 모든 머신/모든 위치(샘플) 시도 후 ΔTWT 최소 위치에 삽입
# ───────────────────────────────────────────────────────────────────────────────

def initial_solution(inst: Instance, d: List[int], w: List[int], rng: random.Random) -> Chromosome:
    jobs = list(range(inst.numJob))
    rng.shuffle(jobs)
    ch = Chromosome([[] for _ in range(inst.numMch)])
    evaluate_full(ch, inst, d, w)

    for j in jobs:
        base_total = ch.twt if ch.twt is not None else 0
        best_delta = math.inf
        best = None
        for mi in range(inst.numMch):
            seq = ch.seqs[mi]
            twt_old, C = twt_of_machine(seq, mi, inst, d, w)
            cand_positions = [0] if len(seq)==0 else candidate_positions_by_due(seq, C, d, j, window=8)
            for pos in cand_positions:
                cand = seq[:pos] + [j] + seq[pos:]
                twt_new, _ = twt_of_machine(cand, mi, inst, d, w)
                delta = (base_total - twt_old) + twt_new - base_total
                if delta < best_delta:
                    best_delta = delta
                    best = (mi, pos, twt_new)
        mi, pos, twt_new = best
        ch.seqs[mi].insert(pos, j)
        ch.twt = ch.twt - ch.machine_twt[mi] + twt_new
        ch.machine_twt[mi] = twt_new
    return ch

def initialize_population(inst: Instance, d: List[int], w: List[int], P: int, rng: random.Random) -> List[Chromosome]:
    return [initial_solution(inst, d, w, rng) for _ in range(P)]

# ───────────────────────────────────────────────────────────────────────────────
# 교차: Local Search Enhanced One-Point Crossover
#  - 부모1 컷 기준 좌/우 → 자식1/자식2
#  - 부모2에서 누락된 작업은 같은 머신에 best-position(TWT)로 삽입(샘플 포지션)
# ───────────────────────────────────────────────────────────────────────────────

def crossover_lse_opx(p1: Chromosome, p2: Chromosome, inst: Instance, d: List[int], w: List[int], rng: random.Random) -> Tuple[Chromosome, Chromosome]:
    m = inst.numMch
    child1 = Chromosome([[] for _ in range(m)])
    child2 = Chromosome([[] for _ in range(m)])
    evaluate_full(child1, inst, d, w)
    evaluate_full(child2, inst, d, w)

    for mi in range(m):
        cut = rng.randrange(0, len(p1.seqs[mi]) + 1)
        left = p1.seqs[mi][:cut]
        right = p1.seqs[mi][cut:]
        child1.seqs[mi].extend(left)
        child2.seqs[mi].extend(right)

    evaluate_full(child1, inst, d, w)
    evaluate_full(child2, inst, d, w)

    set_c1 = set().union(*child1.seqs)
    set_c2 = set().union(*child2.seqs)

    miss1 = [[] for _ in range(m)]
    miss2 = [[] for _ in range(m)]
    for mi in range(m):
        for j in p2.seqs[mi]:
            if j not in set_c1: miss1[mi].append(j)
            if j not in set_c2: miss2[mi].append(j)

    def insert_missing(child: Chromosome, missing_per_m: List[List[int]]):
        for mi in range(m):
            for j in missing_per_m[mi]:
                seq = child.seqs[mi]
                base_total = child.twt
                twt_old, C = twt_of_machine(seq, mi, inst, d, w)
                best_delta = math.inf
                best_pos = 0
                best_twt_new = twt_old
                cand_positions = [0] if len(seq)==0 else candidate_positions_by_due(seq, C, d, j, window=8)
                for pos in cand_positions:
                    cand = seq[:pos] + [j] + seq[pos:]
                    twt_new, _ = twt_of_machine(cand, mi, inst, d, w)
                    delta = (base_total - twt_old) + twt_new - base_total
                    if delta < best_delta:
                        best_delta = delta
                        best_pos = pos
                        best_twt_new = twt_new
                child.seqs[mi].insert(best_pos, j)
                child.twt = child.twt - twt_old + best_twt_new
                child.machine_twt[mi] = best_twt_new

    insert_missing(child1, miss1)
    insert_missing(child2, miss2)
    return child1, child2

# ───────────────────────────────────────────────────────────────────────────────
# Local Search (논문 흐름: Intra → Insertion → Swap)
#   - First-Improvement: 개선 발견 즉시 적용(속도)
#   - 포지션 샘플: due 근처 ±window + 양끝
# ───────────────────────────────────────────────────────────────────────────────

def machines_by_priority_TWT(ch: Chromosome) -> List[int]:
    idx = list(range(len(ch.seqs)))
    mt = ch.machine_twt if ch.machine_twt is not None else [0]*len(ch.seqs)
    idx.sort(key=lambda i: mt[i], reverse=True)
    return idx

def ls_intra_machine(ch: Chromosome, inst: Instance, d: List[int], w: List[int], dnn: float, pos_window: int = 10) -> bool:
    improved_any = False
    order = machines_by_priority_TWT(ch)
    kmax = max(1, math.ceil(dnn * len(order)))
    for t in range(kmax):
        mi = order[t]
        while True:
            seq = ch.seqs[mi]
            L = len(seq)
            if L <= 1:
                break
            base_total = ch.twt
            twt_old, C = twt_of_machine(seq, mi, inst, d, w)
            improved = False

            # tardy·가중치 기준 우선
            idxs = list(range(L))
            def tardy_score(k):
                j = seq[k]
                tard = C[k] - d[j]
                return (1 if tard > 0 else 0, w[j])
            idxs.sort(key=tardy_score, reverse=True)

            for i in idxs:
                j = seq[i]
                cand_positions = candidate_positions_by_due(seq, C, d, j, window=pos_window)
                if 0 not in cand_positions: cand_positions.insert(0,0)
                if L not in cand_positions: cand_positions.append(L)
                for pos in cand_positions:
                    if pos == i or pos == i+1:
                        continue
                    seq_wo = seq[:i] + seq[i+1:]
                    pos_adj = pos if pos <= i else pos-1
                    cand = seq_wo[:pos_adj] + [j] + seq_wo[pos_adj:]
                    twt_new, _ = twt_of_machine(cand, mi, inst, d, w)
                    delta = (base_total - twt_old) + twt_new - base_total
                    if delta < 0:
                        # 적용
                        del ch.seqs[mi][i]
                        ch.seqs[mi].insert(pos_adj, j)
                        ch.twt = ch.twt - ch.machine_twt[mi] + twt_new
                        ch.machine_twt[mi] = twt_new
                        improved_any = True
                        improved = True
                        break
                if improved:
                    break
            if not improved:
                break
    return improved_any

def ls_insertion(ch: Chromosome, inst: Instance, d: List[int], w: List[int], dins: float, pos_window: int = 10) -> bool:
    improved_any = False
    order = machines_by_priority_TWT(ch)
    kmax = max(1, math.ceil(dins * len(order)))
    for t in range(kmax):
        mi = order[t]
        while True:
            seq_i = ch.seqs[mi]
            L = len(seq_i)
            if L == 0:
                break
            twt_i_old, C_i = twt_of_machine(seq_i, mi, inst, d, w)
            base_total = ch.twt
            improved = False

            idxs = list(range(L))
            def tardy_score_i(k):
                j = seq_i[k]
                tard = C_i[k] - d[j]
                return (1 if tard > 0 else 0, w[j])
            idxs.sort(key=tardy_score_i, reverse=True)

            for idx_i in idxs:
                j = seq_i[idx_i]
                seq_i_wo = seq_i[:idx_i] + seq_i[idx_i+1:]
                twt_i_new, _ = twt_of_machine(seq_i_wo, mi, inst, d, w)
                base_wo_i = (base_total - twt_i_old) + twt_i_new

                for mj in range(inst.numMch):
                    if mj == mi:
                        continue
                    seq_j = ch.seqs[mj]
                    twt_j_old, C_j = twt_of_machine(seq_j, mj, inst, d, w)
                    cand_positions = [0] if len(seq_j)==0 else candidate_positions_by_due(seq_j, C_j, d, j, window=pos_window)
                    if 0 not in cand_positions: cand_positions.insert(0,0)
                    if len(seq_j) not in cand_positions: cand_positions.append(len(seq_j))

                    for pos in cand_positions:
                        cand_j = seq_j[:pos] + [j] + seq_j[pos:]
                        twt_j_new, _ = twt_of_machine(cand_j, mj, inst, d, w)
                        delta = base_wo_i - twt_j_old + twt_j_new - base_total
                        if delta < 0:
                            # 적용
                            del ch.seqs[mi][idx_i]
                            ch.seqs[mj].insert(pos, j)
                            ch.twt = ch.twt - ch.machine_twt[mi] - ch.machine_twt[mj] + twt_i_new + twt_j_new
                            ch.machine_twt[mi] = twt_i_new
                            ch.machine_twt[mj] = twt_j_new
                            improved_any = True
                            improved = True
                            break
                    if improved:
                        break
                if improved:
                    break
            if not improved:
                break
    return improved_any

def ls_swap(ch: Chromosome, inst: Instance, d: List[int], w: List[int], dswap: float, pos_window: int = 8, max_pairs_per_machine: int = 20) -> bool:
    """
    스왑(머신 간 교환) 연산자
    - 우선순위: TWT 높은 머신부터 탐색 (dswap 비율)
    - 작업 후보: tardy·가중치 기준 상위 일부만(최대 max_pairs_per_machine) 선택
    - 포지션은 due 근처 ±window + 양끝만 평가
    - first-improvement: 개선 발견 즉시 적용
    """
    if dswap <= 0.0:
        return False

    improved_any = False
    order = machines_by_priority_TWT(ch)
    kmax = max(1, math.ceil(dswap * len(order)))
    m = inst.numMch

    for t in range(kmax):
        mi = order[t]
        while True:
            seq_i = ch.seqs[mi]
            Li = len(seq_i)
            if Li == 0:
                break
            twt_i_old, C_i = twt_of_machine(seq_i, mi, inst, d, w)
            base_total = ch.twt

            # 후보 작업: tardy/가중치 기준 상위
            idxs_i = list(range(Li))
            def score_i(k):
                j = seq_i[k]
                tard = C_i[k] - d[j]
                return (1 if tard>0 else 0, w[j])
            idxs_i.sort(key=score_i, reverse=True)
            idxs_i = idxs_i[:max_pairs_per_machine]

            improved = False
            for idx_i in idxs_i:
                x = seq_i[idx_i]
                seq_i_wo = seq_i[:idx_i] + seq_i[idx_i+1:]
                # i-머신에서 y 삽입용 위치 후보를 만들기 위해 C_i_wo를 대강 추정하기보다,
                # 실제 평가 시 candidate_positions_by_due에 기존 C_i를 사용(근사)하고 pos 조정
                # → 포지션 샘플 정확도는 조금 떨어지지만 속도·안정성 우선

                for mj in range(m):
                    if mj == mi:
                        continue
                    seq_j = ch.seqs[mj]
                    Lj = len(seq_j)
                    if Lj == 0:
                        continue
                    twt_j_old, C_j = twt_of_machine(seq_j, mj, inst, d, w)

                    # j-머신 후보 작업(상위)
                    idxs_j = list(range(Lj))
                    def score_j(k):
                        j2 = seq_j[k]
                        tard = C_j[k] - d[j2]
                        return (1 if tard>0 else 0, w[j2])
                    idxs_j.sort(key=score_j, reverse=True)
                    idxs_j = idxs_j[:max_pairs_per_machine]

                    for idx_j in idxs_j:
                        y = seq_j[idx_j]

                        # y를 i에 삽입, x를 j에 삽입 — 포지션 샘플
                        seq_j_wo = seq_j[:idx_j] + seq_j[idx_j+1:]

                        # i 쪽 포지션
                        cand_pos_i = [0] if len(seq_i_wo)==0 else candidate_positions_by_due(seq_i, C_i, d, y, window=pos_window)
                        if 0 not in cand_pos_i: cand_pos_i.insert(0,0)
                        if len(seq_i_wo) not in cand_pos_i: cand_pos_i.append(len(seq_i_wo))

                        # j 쪽 포지션
                        cand_pos_j = [0] if len(seq_j_wo)==0 else candidate_positions_by_due(seq_j, C_j, d, x, window=pos_window)
                        if 0 not in cand_pos_j: cand_pos_j.insert(0,0)
                        if len(seq_j_wo) not in cand_pos_j: cand_pos_j.append(len(seq_j_wo))

                        best_twt_i = math.inf
                        best_pos_i = 0
                        for pos_i in cand_pos_i:
                            cand_i = seq_i_wo[:pos_i] + [y] + seq_i_wo[pos_i:]
                            val_i, _ = twt_of_machine(cand_i, mi, inst, d, w)
                            if val_i < best_twt_i:
                                best_twt_i = val_i
                                best_pos_i = pos_i

                        best_twt_j = math.inf
                        best_pos_j = 0
                        for pos_j in cand_pos_j:
                            cand_j2 = seq_j_wo[:pos_j] + [x] + seq_j_wo[pos_j:]
                            val_j2, _ = twt_of_machine(cand_j2, mj, inst, d, w)
                            if val_j2 < best_twt_j:
                                best_twt_j = val_j2
                                best_pos_j = pos_j

                        delta = (base_total - ch.machine_twt[mi] - ch.machine_twt[mj] + best_twt_i + best_twt_j) - base_total
                        if delta < 0:
                            # 적용
                            del ch.seqs[mi][idx_i]
                            del ch.seqs[mj][idx_j if mj != mi else (idx_j - (1 if idx_j>idx_i else 0))]
                            ch.seqs[mi].insert(best_pos_i, y)
                            ch.seqs[mj].insert(best_pos_j, x)
                            ch.twt = ch.twt - ch.machine_twt[mi] - ch.machine_twt[mj] + best_twt_i + best_twt_j
                            ch.machine_twt[mi] = best_twt_i
                            ch.machine_twt[mj] = best_twt_j
                            improved_any = True
                            improved = True
                            break
                    if improved:
                        break
                if improved:
                    break
            if not improved:
                break
    return improved_any

def local_search(ch: Chromosome, inst: Instance, d: List[int], w: List[int], dnn: float, dins: float, dswap: float) -> None:
    while True:
        improved = False
        if ls_intra_machine(ch, inst, d, w, dnn, pos_window=10):
            improved = True
        if ls_insertion(ch, inst, d, w, dins, pos_window=10):
            improved = True
        if ls_swap(ch, inst, d, w, dswap, pos_window=8, max_pairs_per_machine=20):
            improved = True
        if not improved:
            break

# ───────────────────────────────────────────────────────────────────────────────
# GA 본체
# ───────────────────────────────────────────────────────────────────────────────

def unique_signature(ch: Chromosome) -> Tuple[Tuple[int, ...], ...]:
    return tuple(tuple(seq) for seq in ch.seqs)

def select_parents(pop: List[Chromosome], rng: random.Random) -> Tuple[Chromosome, Chromosome]:
    p1 = rng.choice(pop)
    p2 = rng.choice(pop)
    tries = 0
    while p2 is p1 and tries < 5:
        p2 = rng.choice(pop)
        tries += 1
    return p1, p2

def hga_schedulling(
    prob: Instance,
    time_limit_sec: float = 5.0,
    P: int = 20,
    dnn: float = 0.7,
    dins: float = 0.5,
    dswap: float = 0.1,
    seed: Optional[int] = None,
    max_generations: int = 10_000,
    instance_name: Optional[str] = None,
) -> Schedule:
    """
    입력: module.Instance
    출력: module.Schedule  (최종 objective는 패키지의 get_obj로 계산)
    - Instance는 시작 시 1회 deepcopy 하고, 최종 디코딩 전에 reset_instance 로 초기화하여 재사용 가능
    """
    rng = random.Random(seed)

    # 인스턴스 1회 deepcopy 후, 내부 참조 사용
    inst = prob.deepcopy()
    d, w = build_dw(inst)

    # 초기 집단
    pop = initialize_population(inst, d, w, P, rng)
    sigset = {unique_signature(ch) for ch in pop}
    pop.sort(key=lambda c: c.twt)
    best = pop[0].copy()

    t0 = time.time()
    gen = 0

    # 로그 마일스톤: max_generations의 10% 지점들
    if max_generations and max_generations > 0:
        log_marks = {max(1, math.ceil(max_generations * k / 10000)) for k in range(1, 10001)}
    else:
        log_marks = set()
    inst_label = instance_name or getattr(prob, "name", "unknown")

    while time.time() - t0 < time_limit_sec and gen < max_generations:
        gen += 1
        p1, p2 = select_parents(pop, rng)
        c1, c2 = crossover_lse_opx(p1, p2, inst, d, w, rng)
        local_search(c1, inst, d, w, dnn, dins, dswap)
        local_search(c2, inst, d, w, dnn, dins, dswap)
        for child in (c1, c2):
            sig = unique_signature(child)
            if sig in sigset:
                continue
            # 가장 나쁜 해와 교체
            worst = max(pop, key=lambda c: c.twt)
            if child.twt < worst.twt:
                pop.remove(worst)
                sigset.discard(unique_signature(worst))
                pop.append(child)
                sigset.add(sig)
                if child.twt < best.twt:
                    best = child.copy()

        if gen in log_marks:
            pct = int(round(100 * gen / max_generations))
            elapsed = time.time() - t0
            print(f"[HGA][{inst_label}] gen {gen}/{max_generations} ({pct}%) | best_wT={best.twt} | elapsed={elapsed:.2f}s")

    # ── 염색체 → Instance 디코딩: Machine.process 사용 ───────────────────────
    reset_instance(inst)  # 재사용/오염 방지
    for mi, seq in enumerate(best.seqs):
        mch = inst.findMch(mi)
        for j in seq:
            job = inst.findJob(j)
            mch.process(job)

    # 패키지의 get_obj로 최종 목적함수(wT) 계산 후 Schedule 생성
    obj = get_obj(inst)  # default OBJECTIVE_FUNCTION='wT'
    sched = Schedule('HGA_TWT', inst, obj)
    sched.status = 'OK'
    sched.comp_time = f"{time.time()-t0:.3f}s"
    return sched
